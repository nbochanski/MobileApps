//
//  ViewController.swift
//  Multiply
//
//  Created by  on 10/6/20.
//  Copyright © 2020 BoBoApps. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var resultLabel: UILabel!
    
    @IBOutlet weak var firstTextField: UITextField!
    
    @IBOutlet weak var secondTextField: UITextField!
    
    @IBOutlet weak var myImageView: UIImageView!
    
    var resultOne: Double = 0
    var resultTwo: Double = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        resultLabel.text = "RESULT"
    }
    
    @IBAction func multiplyButton(_ sender: UIButton)
    {
        
        let resultOne = firstTextField?.text ?? "0"
        let numOne = Double(resultOne) ?? 0
        
        let resultTwo = secondTextField?.text ?? "0"
        let numTwo = Double(resultTwo) ?? 0
        
        let finalResult = numOne * numTwo
        resultLabel.text = String(finalResult)
        
        firstTextField.text = ""
        secondTextField.text = ""
        
        if finalResult == 64
        {
            myImageView.image = UIImage(named: "marioKart")
        }
        else if finalResult.truncatingRemainder(dividingBy: 2) == 0
        {
            myImageView.image = UIImage(named: "funny")
        }
        else
        {
            myImageView.image = UIImage(named: "evenFunnier")
        }
    }
    
}

